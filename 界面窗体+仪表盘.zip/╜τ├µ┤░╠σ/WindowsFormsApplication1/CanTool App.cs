﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class CanTool_App : Form
    {
        public CanTool_App()
        {
            InitializeComponent();
        }

        private void button_begin_Click(object sender, EventArgs e)
        {
            button_stop.Enabled = true;
            button_begin.Enabled = false;
        }

        private void button_stop_Click(object sender, EventArgs e)
        {
            button_stop.Enabled = false;
            button_begin.Enabled = true;
        }

        private void cOMSettingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.Show();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button_show2_Click(object sender, EventArgs e)
        {
            instrument_panel f2 = new instrument_panel();
            f2.Show();
        
        } 
    }
}
