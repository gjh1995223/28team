﻿namespace WindowsFormsApplication1
{
    partial class CanTool_App
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.startToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.closeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.settingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cOMSettingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cANSettingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.dataerror = new System.Windows.Forms.Label();
            this.dlcerror = new System.Windows.Forms.Label();
            this.iderror = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.button_send = new System.Windows.Forms.Button();
            this.textBox_DATA = new System.Windows.Forms.TextBox();
            this.textBox_DLC = new System.Windows.Forms.TextBox();
            this.textBox_CANID = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.button2 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.button_savefile = new System.Windows.Forms.Button();
            this.button_stop = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.button_begin = new System.Windows.Forms.Button();
            this.sp = new System.IO.Ports.SerialPort(this.components);
            this.sp2 = new System.IO.Ports.SerialPort(this.components);
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.menuStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.AutoSize = false;
            this.menuStrip1.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.startToolStripMenuItem,
            this.settingToolStripMenuItem,
            this.helpToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(740, 36);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // startToolStripMenuItem
            // 
            this.startToolStripMenuItem.AutoSize = false;
            this.startToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openToolStripMenuItem,
            this.closeToolStripMenuItem});
            this.startToolStripMenuItem.Name = "startToolStripMenuItem";
            this.startToolStripMenuItem.Size = new System.Drawing.Size(70, 32);
            this.startToolStripMenuItem.Text = "start";
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.Size = new System.Drawing.Size(113, 24);
            this.openToolStripMenuItem.Text = "open";
            // 
            // closeToolStripMenuItem
            // 
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new System.Drawing.Size(113, 24);
            this.closeToolStripMenuItem.Text = "close";
            // 
            // settingToolStripMenuItem
            // 
            this.settingToolStripMenuItem.AutoSize = false;
            this.settingToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cOMSettingToolStripMenuItem,
            this.cANSettingToolStripMenuItem});
            this.settingToolStripMenuItem.Name = "settingToolStripMenuItem";
            this.settingToolStripMenuItem.Size = new System.Drawing.Size(70, 32);
            this.settingToolStripMenuItem.Text = "setting";
            // 
            // cOMSettingToolStripMenuItem
            // 
            this.cOMSettingToolStripMenuItem.Name = "cOMSettingToolStripMenuItem";
            this.cOMSettingToolStripMenuItem.Size = new System.Drawing.Size(162, 24);
            this.cOMSettingToolStripMenuItem.Text = "COM setting";
            this.cOMSettingToolStripMenuItem.Click += new System.EventHandler(this.cOMSettingToolStripMenuItem_Click);
            // 
            // cANSettingToolStripMenuItem
            // 
            this.cANSettingToolStripMenuItem.Name = "cANSettingToolStripMenuItem";
            this.cANSettingToolStripMenuItem.Size = new System.Drawing.Size(162, 24);
            this.cANSettingToolStripMenuItem.Text = "CAN setting";
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.AutoSize = false;
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(70, 32);
            this.helpToolStripMenuItem.Text = "help";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.AutoSize = false;
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(70, 32);
            this.exitToolStripMenuItem.Text = "exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.textBox2);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.dataerror);
            this.groupBox1.Controls.Add(this.dlcerror);
            this.groupBox1.Controls.Add(this.iderror);
            this.groupBox1.Controls.Add(this.listBox1);
            this.groupBox1.Controls.Add(this.button_send);
            this.groupBox1.Controls.Add(this.textBox_DATA);
            this.groupBox1.Controls.Add(this.textBox_DLC);
            this.groupBox1.Controls.Add(this.textBox_CANID);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox1.Location = new System.Drawing.Point(12, 49);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(716, 173);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Send CAN Message";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(627, 15);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(48, 23);
            this.button1.TabIndex = 13;
            this.button1.Text = "发送";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(531, 15);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(90, 23);
            this.textBox2.TabIndex = 12;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(462, 19);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(63, 14);
            this.label6.TabIndex = 11;
            this.label6.Text = "用户指令";
            // 
            // dataerror
            // 
            this.dataerror.AutoSize = true;
            this.dataerror.Location = new System.Drawing.Point(390, 141);
            this.dataerror.Name = "dataerror";
            this.dataerror.Size = new System.Drawing.Size(0, 14);
            this.dataerror.TabIndex = 10;
            // 
            // dlcerror
            // 
            this.dlcerror.AutoSize = true;
            this.dlcerror.Location = new System.Drawing.Point(192, 88);
            this.dlcerror.Name = "dlcerror";
            this.dlcerror.Size = new System.Drawing.Size(0, 14);
            this.dlcerror.TabIndex = 9;
            // 
            // iderror
            // 
            this.iderror.AutoSize = true;
            this.iderror.Location = new System.Drawing.Point(189, 32);
            this.iderror.Name = "iderror";
            this.iderror.Size = new System.Drawing.Size(0, 14);
            this.iderror.TabIndex = 8;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 14;
            this.listBox1.Location = new System.Drawing.Point(464, 44);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(235, 88);
            this.listBox1.TabIndex = 7;
            // 
            // button_send
            // 
            this.button_send.Location = new System.Drawing.Point(587, 138);
            this.button_send.Name = "button_send";
            this.button_send.Size = new System.Drawing.Size(100, 30);
            this.button_send.TabIndex = 6;
            this.button_send.Text = "Send";
            this.button_send.UseVisualStyleBackColor = true;
            this.button_send.Click += new System.EventHandler(this.button_send_Click);
            // 
            // textBox_DATA
            // 
            this.textBox_DATA.Location = new System.Drawing.Point(89, 138);
            this.textBox_DATA.Name = "textBox_DATA";
            this.textBox_DATA.Size = new System.Drawing.Size(278, 23);
            this.textBox_DATA.TabIndex = 5;
            // 
            // textBox_DLC
            // 
            this.textBox_DLC.Location = new System.Drawing.Point(89, 85);
            this.textBox_DLC.Name = "textBox_DLC";
            this.textBox_DLC.Size = new System.Drawing.Size(79, 23);
            this.textBox_DLC.TabIndex = 4;
            // 
            // textBox_CANID
            // 
            this.textBox_CANID.Location = new System.Drawing.Point(89, 29);
            this.textBox_CANID.Name = "textBox_CANID";
            this.textBox_CANID.Size = new System.Drawing.Size(79, 23);
            this.textBox_CANID.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(22, 141);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 14);
            this.label3.TabIndex = 2;
            this.label3.Text = "DATA:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(25, 88);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 14);
            this.label2.TabIndex = 1;
            this.label2.Text = "DLC:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(22, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 14);
            this.label1.TabIndex = 0;
            this.label1.Text = "CAN ID:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.textBox1);
            this.groupBox2.Controls.Add(this.treeView1);
            this.groupBox2.Controls.Add(this.button2);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.button_savefile);
            this.groupBox2.Controls.Add(this.button_stop);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.button_begin);
            this.groupBox2.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox2.Location = new System.Drawing.Point(12, 228);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(716, 228);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Receive CAN message";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(627, 71);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(46, 23);
            this.textBox1.TabIndex = 18;
            this.textBox1.Visible = false;
            // 
            // treeView1
            // 
            this.treeView1.Location = new System.Drawing.Point(118, 28);
            this.treeView1.Name = "treeView1";
            this.treeView1.Size = new System.Drawing.Size(474, 189);
            this.treeView1.TabIndex = 17;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(598, 123);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(101, 37);
            this.button2.TabIndex = 15;
            this.button2.Text = "dash board";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(598, 38);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(77, 14);
            this.label5.TabIndex = 9;
            this.label5.Text = "当前串口：";
            // 
            // button_savefile
            // 
            this.button_savefile.Location = new System.Drawing.Point(599, 185);
            this.button_savefile.Name = "button_savefile";
            this.button_savefile.Size = new System.Drawing.Size(100, 37);
            this.button_savefile.TabIndex = 6;
            this.button_savefile.Text = "Save file";
            this.button_savefile.UseVisualStyleBackColor = true;
            this.button_savefile.Click += new System.EventHandler(this.button_savefile_Click);
            // 
            // button_stop
            // 
            this.button_stop.Enabled = false;
            this.button_stop.Location = new System.Drawing.Point(28, 142);
            this.button_stop.Name = "button_stop";
            this.button_stop.Size = new System.Drawing.Size(75, 75);
            this.button_stop.TabIndex = 2;
            this.button_stop.Text = "Stop";
            this.button_stop.UseVisualStyleBackColor = true;
            this.button_stop.Click += new System.EventHandler(this.button_stop_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(22, 38);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 14);
            this.label4.TabIndex = 1;
            // 
            // button_begin
            // 
            this.button_begin.Location = new System.Drawing.Point(28, 28);
            this.button_begin.Name = "button_begin";
            this.button_begin.Size = new System.Drawing.Size(75, 75);
            this.button_begin.TabIndex = 0;
            this.button_begin.Text = "Begin";
            this.button_begin.UseVisualStyleBackColor = true;
            this.button_begin.Click += new System.EventHandler(this.button_begin_Click);
            // 
            // sp
            // 
            this.sp.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.serialPort1_DataReceived);
            // 
            // sp2
            // 
            this.sp2.BaudRate = 115200;
            // 
            // CanTool_App
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(740, 468);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "CanTool_App";
            this.Text = "CanTool_App";
            this.Load += new System.EventHandler(this.CanTool_App_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem startToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem closeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem settingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cOMSettingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cANSettingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button_send;
        private System.Windows.Forms.TextBox textBox_DATA;
        private System.Windows.Forms.TextBox textBox_DLC;
        private System.Windows.Forms.TextBox textBox_CANID;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button_stop;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button_begin;
        private System.Windows.Forms.Button button_savefile;
        private System.Windows.Forms.Label label5;
        private System.IO.Ports.SerialPort sp;
        private System.IO.Ports.SerialPort sp2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label dataerror;
        private System.Windows.Forms.Label dlcerror;
        private System.Windows.Forms.Label iderror;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TreeView treeView1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button1;
        private System.IO.Ports.SerialPort serialPort1;
    }
}